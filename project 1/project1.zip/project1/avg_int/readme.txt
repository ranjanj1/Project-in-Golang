Step 1: Load the file in GOLang editor (preferably VSCODE)
Step 2: Open terminal and navigate to the folder where code is avaible in your machine (if not already)
Step 3: Build it using command: "go build ."  (do not use ")
Step 4: Then run the following command test the code: "./avg_int -M 10 -fname input.txt"
                   In the above command "10" is the number of workers. You can change the it to any integer to verify for other number of workers
                   "input.txt" is the input file provided which contains the list of integers values. modify to check for other values



